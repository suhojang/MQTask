package com.kwic.common.log;

public abstract class Listener {
	public abstract void write(String msg);
}
