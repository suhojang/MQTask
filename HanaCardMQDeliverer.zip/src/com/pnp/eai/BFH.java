package com.pnp.eai;

public class BFH {
	public void setResultCode(String s){
		
	}
}
