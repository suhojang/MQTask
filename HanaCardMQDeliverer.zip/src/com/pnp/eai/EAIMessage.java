package com.pnp.eai;

public class EAIMessage {
	private String[] sample	= new String[]{
			"7507211347520장정훈                                  0120100604                                                                                                                                                                                           "
			,"750721       장정훈                                  029361439831                                  강원                                                                                                                                                   "
			,"6410145100182                                        0320130307                                                                                                                                                                                           "
	};
	
	public BFH getBFH(){
		return new BFH();
	}
	int idx	= 0;
	public byte[] getUserData(){
		if(idx>=sample.length)
			return null;
//			idx	= 0;
		return sample[idx++].getBytes();
	}
}
