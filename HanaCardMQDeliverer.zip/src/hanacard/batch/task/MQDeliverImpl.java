package hanacard.batch.task;

import hanacard.batch.struct.MQStruct;

import java.io.File;
import java.util.Map;

import com.kwic.common.log.LogFactory;
import com.kwic.common.log.Logger;
import com.kwic.config.Config;
import com.kwic.exception.DefinedException;
import com.kwic.math.Calculator;
import com.kwic.support.Crypto;
import com.kwic.telegram.tcp.JTcpManager;
import com.kwic.xml.parser.JXParser;

/**
 * deliver MQ request and response 
 * */
public abstract class MQDeliverImpl{
	protected Logger		logger	= LogFactory.getLogger("app");
	
	protected Config config;
	protected Map<String,String> dataMap;
	protected JXParser struct;
	protected JXParser responseXml;
	protected byte[] requestBytes;
	protected byte[] responseBytes;
	protected String rtnCode;
	protected boolean	isError;
	protected int threadNo;
	
	public MQDeliverImpl(int threadNo, Map<String,String> dataMap,byte[] requestBytes) throws Exception{
		this.threadNo	= threadNo;
		this.dataMap		= dataMap;
		this.requestBytes	= requestBytes;
		responseBytes		= new byte[requestBytes.length];
		System.arraycopy(requestBytes,0,responseBytes,0,requestBytes.length);
		config				= Config.getInstance();
		struct				= new JXParser(new File(config.getProperty("agent.struct.folder")+"/"+dataMap.get(config.getProperty("mq.request.code"))+".xml"));
		rtnCode				= config.getProperty("mq.returncode.normal");
	}
	
	public void run(){
		String request	= null;
		String xml		= null;
		byte[] bytes	= null;
		try{
			try{
				//1. agent 요청메시지 생성
				try{
					request	= exec();
					logger.debug("[Thread_"+threadNo+"] ========== request xml ================");
					logger.debug(request);
				}catch(Exception e){
					throw new DefinedException("Agent 요청전문 생성 중 오류가 발생하였습니다.");
				}
				//2. agent 요청메시지 송신 및 응답 수신
				try{
					xml		= deliver(request.getBytes(config.getProperty("agent.encoding")));
					logger.debug("[Thread_"+threadNo+"] ========== response xml ================");
					logger.debug(xml);
				}catch(Exception e){
					throw new DefinedException("Agent에 연결할 수 없습니다.");
				}
				//3. agent 응답메시지 분석
				try{
					responseXml	= new JXParser(xml);
					response(responseXml);
				}catch(Exception e){
					throw new DefinedException("Agent 응답전문 처리 중 오류가 발생하였습니다.");
				}
				
			}catch(Exception e){
				logger.error(e);
				isError	= true;
				//MQ 오류처리
				dataMap.put("RPC"		, config.getProperty("mq.RPC.ERR"));
				dataMap.put("RNM_CYN"	, config.getProperty("mq.RNM_CYN.NO"));
				dataMap.put("FILLER"	, e instanceof DefinedException ? getErrMessage(e.getMessage()):"처리 중 오류가 발생하였습니다.");
			}
			//4. MQ 응답 전문 생성
			bytes	= MQStruct.getInstance().getResponseDatas(dataMap);
			logger.debug("[Thread_"+threadNo+"] response data string ["+new String(bytes)+"]");
			
			if(responseBytes.length>Integer.parseInt(config.getProperty("mq.data.length")))
				System.arraycopy(bytes, 0, responseBytes, Integer.parseInt(config.getProperty("mq.data.startindex")), Integer.parseInt(config.getProperty("mq.data.length")));
			
			else if(requestBytes.length<Integer.parseInt(config.getProperty("mq.data.length"))+Integer.parseInt(config.getProperty("mq.data.startindex")))
				throw new DefinedException("응답 전문의 byte 크기가 설정에 정의된 ["+config.getProperty("mq.data.startindex")+"+"+config.getProperty("mq.data.length")+"] 보다 작습니다.");
			
			else
				responseBytes	= bytes;
			
		}catch(Exception e){
			logger.error(e);
			isError	= true;
			/*프로그램 오류 시 MQ 응답 처리*/
			rtnCode	= config.getProperty("mq.returncode.error");
		}
	}
	public String getRtnCode(){
		return rtnCode;
	}
	public boolean getIsError(){
		return isError;
	}
	public byte[] getResponseBytes(){
		return responseBytes;
	}
	
	
	public String deliver(byte[] bytes) throws Exception{
		byte[] response	= JTcpManager.getInstance().sendMessage(config.getProperty("agent.ip"), Integer.parseInt(config.getProperty("agent.port")), bytes,true,(int)Calculator.calculate(config.getProperty("agent.timeout")));
		
		return new String(response, config.getProperty("agent.encoding"));
	}
	
	public String getErrMessage(String msg){
		if(msg==null)
			return "";
		int size	= Integer.parseInt(config.getProperty("mq.MSG.length"));
		if(size>=msg.getBytes().length)
			return msg;
		
		byte[] bytes	= new byte[size];
		System.arraycopy(msg.getBytes(), 0, bytes, 0, size);
		
		return new String(bytes);
	}
	
	public String getParam(String fieldName, String val) throws Exception{
		if((","+config.getProperty("encrypt.fileds")+",").indexOf(","+fieldName+",")>=0)
			val	= new String(Crypto.encryptBytes(val, config.getProperty("encrypt.key"), config.getProperty("encrypt.encoding")));
		return val;
	}
	
	/**
	 * 요청 송신 및 응답 수신
	 * */
	public abstract String exec() throws Exception;
	/**
	 * 수신 응답 메시지 분석 후 정상처리여부,진위여부,응답메시지 추출
	 * */
	public abstract void response(JXParser response) throws Exception;

}
